
<div class="wrapper">
<div id="content">
            <!--// top-bar -->
            <div class="container-fluid">
                <div class="row">
                    <!-- Stats -->
                    <div class="outer-w3-agile col-xl">
                        <div class="stat-grid p-3 d-flex align-items-center justify-content-between bg-primary">
                            <div class="s-l">
                                <h5>Generate Diaries</h5>
                                
                            </div>
                            <div class="s-r">
                                <a href="<?php echo base_url();?>index.php/Mycontroller/studentadddiary"><h6>Click Here
                                    <i class="far fa-edit"></i>
                                </h6></a>
                            </div>
                        </div>
                        <div class="stat-grid p-3 mt-3 d-flex align-items-center justify-content-between bg-success">
                            <div class="s-l">
                                <h5>Received Diaries</h5>
                                
                            </div>
                            <div class="s-r">
                                <a href="<?php echo base_url();?>index.php/Mycontroller/assigneddiariestables"><h6>Click Here
                                    <i class="far fa-smile"></i>
                                </h6></a>
                            </div>
                        </div>
                        <div class="stat-grid p-3 mt-3 d-flex align-items-center justify-content-between bg-danger">
                            <div class="s-l">
                                <h5>Messages</h5>
                               
                            </div>
                            <div class="s-r">
                                <a href="<?php echo base_url();?>index.php/Mycontroller/studentchat"><h6>Click Here
                                    <i class="fas fa-tasks"></i>
                                </h6></a>
                            </div>
                        </div>
                      
                    </div>
                    <!--// Stats -->
                    <!-- Pie-chart -->
                       <div class="outer-w3-agile col-xl ml-xl-3 mt-xl-0 mt-3">
                        <b><h4 class="tittle-w3-agileits mb-4" style="color: #008080;">SMFWB Office Management Software</h4></b>
                        <div class="row">
						<div class="col-md-4">
						<img src="<?php echo base_url();?>assets/img/smfwb-logo.png" style="width: 120px; margin-top: 50px;">
						</div>
						<div class="col-md-4">
						<img src="<?php echo base_url();?>assets/img/handshake.png" style="width: 180px; margin-top: 70px;">
						</div>
						<div class="col-md-4">
						<img src="<?php echo base_url();?>assets/img/trident-logo (1).png" style="width: 150px; margin-top: 20px;">
						</div>
						</div>
                    </div>
                    <!--// Pie-chart -->
                </div>
            </div>
			
			<div class="copyright-w3layouts py-xl-3 py-2 mt-xl-5 mt-4 text-center" style="margin-top: 150px;">
                <p>© 2021 . All Rights Reserved | Developed by
                    <a href="https://tridentdigitech.com/"> Trident Digitech </a>
                </p>
            </div>
			
			</div>
			
			</div>
          

</body>

</html>